from fastapi import FastAPI, Query
from pydantic import BaseModel
from datetime import datetime
import yfinance as yf

app = FastAPI()

class AnalyzeWaveRequest(BaseModel):
    symbol: str
    timeframe: str

class PTMSetupRequest(BaseModel):
    macro_theme: str
    asset_class: str

@app.post("/analyze-wave")
def analyze_wave(data: AnalyzeWaveRequest):
    return {
        "wave_structure": "Wave 3 of an impulsive bullish cycle",
        "recommendation": "Consider long entry; wave structure suggests upside continuation"
    }

@app.post("/ptm-setup")
def ptm_setup(data: PTMSetupRequest):
    return {
        "setup": f"Buy assets in {data.asset_class} due to {data.macro_theme}"
    }

@app.get("/market-data")
def get_market_data(symbol: str = Query(..., description="Ticker symbol, e.g., AAPL")):
    ticker = yf.Ticker(symbol)
    hist = ticker.history(period="1d")
    if hist.empty:
        return {"error": "No data found for symbol"}
    latest = hist.iloc[-1]
    return {
        "price": round(latest['Close'], 2),
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }
